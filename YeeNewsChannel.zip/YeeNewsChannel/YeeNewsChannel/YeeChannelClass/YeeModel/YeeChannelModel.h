//
//  YeeChannelModel.h
//  YeeNewsChannel
//
//  Created by CoderYee on 2017/2/9.
//  Copyright © 2017年 CoderYee. All rights reserved.
//

#import "YeeBaseModel.h"

@interface YeeChannelModel : YeeBaseModel

@property(nonatomic,copy)NSString    *channelId;
@property(nonatomic,copy)NSString    *channleName;

@end
