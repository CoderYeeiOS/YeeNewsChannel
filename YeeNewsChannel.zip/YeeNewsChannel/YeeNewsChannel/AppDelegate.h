//
//  AppDelegate.h
//  YeeNewsChannel
//
//  Created by CoderYee on 2017/2/9.
//  Copyright © 2017年 CoderYee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

